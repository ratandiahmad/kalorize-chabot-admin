

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Edit Isi File Excel untuk <?php echo e($pelanggan->nama); ?></h1>

        <form action="<?php echo e(route('pelanggans.updateExcel', $pelanggan->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div id="file-data-container">
                <?php $__currentLoopData = $fileData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="category-section" data-category="<?php echo e($category); ?>">
                        <h3><?php echo e($category); ?></h3>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Nama</th>
                                    <th>Harga</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <input type="text" name="data[<?php echo e($category); ?>][<?php echo e($index); ?>][nama]"
                                                value="<?php echo e($item['nama']); ?>" class="form-control">
                                        </td>
                                        <td>
                                            <input type="number"
                                                name="data[<?php echo e($category); ?>][<?php echo e($index); ?>][harga]"
                                                value="<?php echo e($item['harga']); ?>" class="form-control">
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-danger remove-row">Hapus</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <button type="button" class="btn btn-success add-row" data-category="<?php echo e($category); ?>">Tambah
                            Baris</button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Event handler untuk tombol "Tambah Baris"
            document.querySelectorAll('.add-row').forEach(button => {
                button.addEventListener('click', function() {
                    const category = this.getAttribute('data-category');
                    const section = this.closest('.category-section');
                    const tbody = section.querySelector('tbody');
                    const rowCount = tbody.children.length;

                    // Buat baris baru
                    const newRow = document.createElement('tr');
                    newRow.innerHTML = `
                        <td>
                            <input type="text" name="data[${category}][${rowCount}][nama]" class="form-control">
                        </td>
                        <td>
                            <input type="number" name="data[${category}][${rowCount}][harga]" class="form-control">
                        </td>
                        <td>
                            <button type="button" class="btn btn-danger remove-row">Hapus</button>
                        </td>
                    `;

                    tbody.appendChild(newRow);
                });
            });

            // Delegasi event untuk tombol "Hapus"
            document.querySelectorAll('.category-section tbody').forEach(tbody => {
                tbody.addEventListener('click', function(event) {
                    if (event.target.classList.contains('remove-row')) {
                        const row = event.target.closest('tr');
                        row.remove();
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kalorize-chabot-admin\resources\views/pelanggans/show.blade.php ENDPATH**/ ?>