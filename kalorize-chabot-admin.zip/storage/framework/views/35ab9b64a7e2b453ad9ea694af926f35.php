

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2>Daftar Pelanggan</h2>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('pelanggans.create')); ?>" class="btn btn-success mb-3">Tambah Pelanggan</a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama</th>
                    <th>Nomor HP</th>
                    <th>Nama Mitra</th>
                    <th>File Excel</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($pelanggan->nama); ?></td>
                        <td><?php echo e($pelanggan->nomor_hp); ?></td>
                        <td><?php echo e($pelanggan->nama_mitra); ?></td>
                        <td>
                            <?php if($pelanggan->file_excel): ?>
                                <a href="<?php echo e(asset('storage/' . $pelanggan->file_excel)); ?>" target="_blank">Unduh</a>
                            <?php else: ?>
                                Tidak ada file
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('pelanggans.show', $pelanggan->id)); ?>" class="btn btn-info btn-sm">Lihat</a>
                            <a href="<?php echo e(route('pelanggans.edit', $pelanggan->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('pelanggans.destroy', $pelanggan->id)); ?>" method="POST"
                                style="display:inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kalorize-chabot-admin\resources\views/pelanggans/index.blade.php ENDPATH**/ ?>