

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2>Tambah Pelanggan</h2>
        <form action="<?php echo e(route('pelanggans.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-3">
                <label for="nama">Nama</label>
                <input type="text" name="nama" class="form-control" required>
            </div>
            <div class="form-group mb-3">
                <label for="nomor_hp">Nomor HP</label>
                <input type="text" name="nomor_hp" class="form-control" required>
            </div>
            <div class="form-group mb-3">
                <label for="nama_mitra">Nama Mitra</label>
                <input type="text" name="nama_mitra" class="form-control" required>
            </div>
            <div class="form-group mb-3">
                <label for="file_excel">File Excel</label>
                <input type="file" name="file_excel" class="form-control" accept=".xlsx, .xls">
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kalorize-chabot-admin\resources\views/pelanggans/create.blade.php ENDPATH**/ ?>