

<?php $__env->startSection('content'); ?>
    <div class="container mt-4">
        <h2>Edit Pelanggan: <?php echo e($pelanggan->nama); ?></h2>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('pelanggans.update', $pelanggan->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-3">
                <label for="nama" class="form-label">Nama</label>
                <input type="text" name="nama" id="nama" class="form-control"
                    value="<?php echo e(old('nama', $pelanggan->nama)); ?>" required>
            </div>

            <div class="mb-3">
                <label for="nomor_hp" class="form-label">Nomor HP</label>
                <input type="text" name="nomor_hp" id="nomor_hp" class="form-control"
                    value="<?php echo e(old('nomor_hp', $pelanggan->nomor_hp)); ?>" required>
            </div>

            <div class="mb-3">
                <label for="nama_mitra" class="form-label">Nama Mitra</label>
                <input type="text" name="nama_mitra" id="nama_mitra" class="form-control"
                    value="<?php echo e(old('nama_mitra', $pelanggan->nama_mitra)); ?>" required>
            </div>

            <div class="mb-3">
                <label for="file_excel" class="form-label">File Excel</label>
                <input type="file" name="file_excel" id="file_excel" class="form-control" accept=".xlsx, .xls">
                <?php if($pelanggan->file_excel): ?>
                    <small class="form-text text-muted">File saat ini: <a
                            href="<?php echo e(asset('storage/' . $pelanggan->file_excel)); ?>" target="_blank">Unduh</a></small>
                <?php endif; ?>
            </div>

            <button type="submit" class="btn btn-primary">Perbarui</button>
            <a href="<?php echo e(route('pelanggans.index')); ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kalorize-chabot-admin\resources\views/pelanggans/edit.blade.php ENDPATH**/ ?>